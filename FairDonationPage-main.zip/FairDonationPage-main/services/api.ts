/**
 * Mock API service - simulates backend interaction.
 * All functions return Promises with artificial delay.
 */
import type { Hostel, Activity, Donation, HostelStatus, ActivityStatus } from "@/lib/data";
import {
  mockHostels,
  mockDonations,
  mockActivities,
  getHostelById,
  getVerifiedHostels,
  getHostelsByStatus,
  getApprovedActivities,
  getPendingActivities,
  getActivitiesByHostel,
  getDonationsForHostel,
  getTotalDonations,
  getTotalDonors,
} from "@/lib/data";

const delay = (ms = 300) => new Promise((r) => setTimeout(r, ms));

// ============ HOSTEL API ============
export async function fetchVerifiedHostels(): Promise<Hostel[]> {
  await delay();
  return getVerifiedHostels();
}

export async function fetchHostelById(id: string): Promise<Hostel | null> {
  await delay();
  return getHostelById(id) ?? null;
}

export async function fetchHostelsByStatus(status: HostelStatus): Promise<Hostel[]> {
  await delay();
  return getHostelsByStatus(status);
}

export async function registerHostel(data: {
  name: string;
  type: string;
  population: number;
  description: string;
  mission: string;
  contact_phone: string;
  documents: string[];
}): Promise<Hostel> {
  await delay(500);
  const newHostel: Hostel = {
    id: `h${Date.now()}`,
    name: data.name,
    type: data.type as Hostel["type"],
    status: "PENDING",
    population: data.population,
    description: data.description,
    mission: data.mission,
    established_date: new Date().toISOString().split("T")[0],
    cover_image: "",
    profile_image: "",
    contact_phone: data.contact_phone,
    documents: data.documents,
    total_received: 0,
  };
  return newHostel;
}

export async function updateHostelProfile(
  hostelId: string,
  data: {
    description: string;
    mission: string;
    cover_image?: string;
    profile_image?: string;
    contact_phone: string;
  }
): Promise<Hostel | null> {
  await delay(500);
  const hostel = getHostelById(hostelId);
  if (!hostel) return null;
  // In a real app, this would persist to DB
  return { ...hostel, ...data };
}

export async function approveHostel(id: string): Promise<boolean> {
  await delay(300);
  return true;
}

export async function rejectHostel(id: string): Promise<boolean> {
  await delay(300);
  return true;
}

// ============ ACTIVITY API ============
export async function fetchApprovedActivities(): Promise<Activity[]> {
  await delay();
  return getApprovedActivities();
}

export async function fetchPendingActivities(): Promise<Activity[]> {
  await delay();
  return getPendingActivities();
}

export async function fetchActivitiesByHostel(hostelId: string): Promise<Activity[]> {
  await delay();
  return getActivitiesByHostel(hostelId);
}

export async function postActivity(data: {
  hostel_id: string;
  image_url: string;
  caption: string;
}): Promise<Activity> {
  await delay(500);
  return {
    id: `a${Date.now()}`,
    hostel_id: data.hostel_id,
    image_url: data.image_url,
    caption: data.caption,
    status: "PENDING",
    date: new Date().toISOString().split("T")[0],
  };
}

export async function publishActivity(id: string): Promise<boolean> {
  await delay(300);
  return true;
}

export async function rejectActivity(id: string): Promise<boolean> {
  await delay(300);
  return true;
}

// ============ DONATION API ============
export async function fetchDonationsForHostel(hostelId: string): Promise<Donation[]> {
  await delay();
  return getDonationsForHostel(hostelId);
}

export async function fetchAllDonations(): Promise<Donation[]> {
  await delay();
  return [...mockDonations];
}

export async function submitDonation(data: {
  amount: number;
  donor_name: string;
  donor_phone: string;
  donor_email?: string;
  hostel_id: string;
}): Promise<Donation> {
  await delay(500);
  return {
    id: `d${Date.now()}`,
    amount: data.amount,
    donor_name: data.donor_name,
    donor_phone: data.donor_phone,
    donor_email: data.donor_email,
    status: "RECEIVED",
    assigned_hostel_id: data.hostel_id,
    date: new Date().toISOString().split("T")[0],
  };
}

export async function markDonationDistributed(id: string): Promise<boolean> {
  await delay(300);
  return true;
}

// ============ STATS API ============
export async function fetchStats(): Promise<{
  totalRaised: number;
  totalDonors: number;
  verifiedHomes: number;
  totalDonations: number;
}> {
  await delay();
  return {
    totalRaised: getTotalDonations(),
    totalDonors: getTotalDonors(),
    verifiedHomes: getVerifiedHostels().length,
    totalDonations: mockDonations.length,
  };
}
