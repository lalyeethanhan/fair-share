"use client";

import { createContext, useContext, useState, useCallback, type ReactNode } from "react";
import { mockUsers, type User } from "@/lib/data";

type AuthRole = "GUEST" | "DONOR" | "HOSTEL_ADMIN" | "ADMIN";

interface AuthContextType {
  user: User | null;
  role: AuthRole;
  login: (userId: string) => void;
  logout: () => void;
  switchRole: (role: AuthRole) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [role, setRole] = useState<AuthRole>("GUEST");

  const login = useCallback((userId: string) => {
    const found = mockUsers.find((u) => u.id === userId);
    if (found) {
      setUser(found);
      setRole(found.role);
    }
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    setRole("GUEST");
  }, []);

  const switchRole = useCallback(
    (newRole: AuthRole) => {
      if (newRole === "GUEST") {
        setUser(null);
        setRole("GUEST");
        return;
      }
      const matchingUser = mockUsers.find((u) => u.role === newRole);
      if (matchingUser) {
        setUser(matchingUser);
        setRole(newRole);
      }
    },
    []
  );

  return (
    <AuthContext.Provider value={{ user, role, login, logout, switchRole }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
