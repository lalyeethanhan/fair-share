import { z } from "zod";

// ============ ENUMS ============
export const HostelTypes = [
  "ORPHANAGE",
  "ELDERLY_CARE",
  "BLIND_SCHOOL",
  "DEAF_SCHOOL",
] as const;
export const HostelStatuses = ["PENDING", "VERIFIED", "REJECTED"] as const;
export const ActivityStatuses = ["PENDING", "APPROVED", "REJECTED"] as const;
export const DonationStatuses = ["RECEIVED", "DISTRIBUTED"] as const;

export type HostelType = (typeof HostelTypes)[number];
export type HostelStatus = (typeof HostelStatuses)[number];
export type ActivityStatus = (typeof ActivityStatuses)[number];
export type DonationStatus = (typeof DonationStatuses)[number];

// ============ INTERFACES ============
export interface Hostel {
  id: string;
  name: string;
  type: HostelType;
  status: HostelStatus;
  population: number;
  // Profile fields
  description: string;
  mission: string;
  established_date: string;
  cover_image: string;
  profile_image: string;
  contact_phone: string;
  // Verification
  documents: string[];
  total_received: number;
}

export interface Donation {
  id: string;
  amount: number;
  donor_name: string;
  donor_phone: string;
  donor_email?: string;
  status: DonationStatus;
  assigned_hostel_id?: string;
  date: string;
}

export interface Activity {
  id: string;
  hostel_id: string;
  image_url: string;
  caption: string;
  status: ActivityStatus;
  date: string;
}

export interface User {
  id: string;
  name: string;
  phone: string;
  email?: string;
  role: "DONOR" | "HOSTEL_ADMIN" | "ADMIN";
  hostel_id?: string;
}

// ============ ZOD SCHEMAS ============

// Registration Step 1: Basic Info
export const hostelRegistrationStep1Schema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  type: z.enum(HostelTypes, { required_error: "Please select a hostel type" }),
  population: z.coerce.number().min(1, "Population must be at least 1"),
});

// Registration Step 2: Profile Setup
export const hostelRegistrationStep2Schema = z.object({
  description: z
    .string()
    .min(10, "Description must be at least 10 characters")
    .max(1000, "Description too long"),
  mission: z
    .string()
    .min(10, "Mission must be at least 10 characters")
    .max(500, "Mission too long"),
  contact_phone: z.string().min(5, "Phone number is required"),
});

// Registration Step 3: Documents
export const hostelRegistrationStep3Schema = z.object({
  documents: z.array(z.string()).min(1, "At least one document is required"),
});

// Profile edit schema (used in hostel dashboard)
export const hostelProfileEditSchema = z.object({
  description: z
    .string()
    .min(10, "Description must be at least 10 characters")
    .max(1000, "Description too long"),
  mission: z
    .string()
    .min(10, "Mission must be at least 10 characters")
    .max(500, "Mission too long"),
  cover_image: z.string().url("Must be a valid URL").optional().or(z.literal("")),
  profile_image: z.string().url("Must be a valid URL").optional().or(z.literal("")),
  contact_phone: z.string().min(5, "Phone number is required"),
});

export const donationGuestSchema = z.object({
  amount: z.coerce.number().min(1000, "Minimum donation is 1,000 MMK"),
  donor_name: z.string().min(2, "Name is required"),
  donor_phone: z.string().min(5, "Phone number is required"),
  donor_email: z.string().email("Invalid email").optional().or(z.literal("")),
});

export const donationLoggedInSchema = z.object({
  amount: z.coerce.number().min(1000, "Minimum donation is 1,000 MMK"),
});

export const activityPostSchema = z.object({
  image_url: z
    .string()
    .min(1, "Image is required"),
  caption: z
    .string()
    .min(5, "Caption must be at least 5 characters")
    .max(500, "Caption too long"),
});

// ============ HOSTEL TYPE LABELS ============
export const hostelTypeLabels: Record<HostelType, string> = {
  ORPHANAGE: "Orphanage",
  ELDERLY_CARE: "Elderly Care",
  BLIND_SCHOOL: "School for the Blind",
  DEAF_SCHOOL: "School for the Deaf",
};

// ============ MOCK DATA ============
export const mockHostels: Hostel[] = [
  {
    id: "h1",
    name: "Golden Heart Orphanage",
    type: "ORPHANAGE",
    status: "VERIFIED",
    population: 47,
    description:
      "Golden Heart Orphanage has been providing a loving home for children in need since 2005. We focus on education, nutrition, and emotional well-being to give every child a chance at a brighter future.",
    mission:
      "To nurture and empower orphaned children through quality education, healthcare, and a loving community environment.",
    established_date: "2005-03-15",
    cover_image:
      "https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?w=1200&h=400&fit=crop",
    profile_image:
      "https://images.unsplash.com/photo-1542810634-71277d95dcbb?w=200&h=200&fit=crop",
    contact_phone: "09-123456789",
    documents: ["/docs/doc1.pdf", "/docs/doc2.pdf"],
    total_received: 2500000,
  },
  {
    id: "h2",
    name: "Shwe Pyi Thar Elderly Home",
    type: "ELDERLY_CARE",
    status: "VERIFIED",
    population: 32,
    description:
      "Shwe Pyi Thar provides compassionate care for elderly residents who need a supportive community. We offer daily activities, medical checkups, and a warm family atmosphere.",
    mission:
      "To provide dignity, comfort, and joy to elderly individuals through compassionate care and a strong sense of community.",
    established_date: "2010-08-20",
    cover_image:
      "https://images.unsplash.com/photo-1516733725897-1aa73b87c8e8?w=1200&h=400&fit=crop",
    profile_image:
      "https://images.unsplash.com/photo-1469571486292-0ba58a3f068b?w=200&h=200&fit=crop",
    contact_phone: "09-987654321",
    documents: ["/docs/doc3.pdf"],
    total_received: 1800000,
  },
  {
    id: "h3",
    name: "Light of Hope Blind School",
    type: "BLIND_SCHOOL",
    status: "VERIFIED",
    population: 25,
    description:
      "Light of Hope provides specialized education and support for visually impaired students. Our trained staff use Braille and assistive technology to open doors to learning.",
    mission:
      "To empower visually impaired individuals with education, skills, and confidence to lead independent lives.",
    established_date: "2012-01-10",
    cover_image:
      "https://images.unsplash.com/photo-1509099836639-18ba1795216d?w=1200&h=400&fit=crop",
    profile_image:
      "https://images.unsplash.com/photo-1532629345422-7515f3d16bb6?w=200&h=200&fit=crop",
    contact_phone: "09-111222333",
    documents: ["/docs/doc4.pdf", "/docs/doc5.pdf"],
    total_received: 900000,
  },
  {
    id: "h4",
    name: "Mingala Deaf School",
    type: "DEAF_SCHOOL",
    status: "PENDING",
    population: 18,
    description:
      "Mingala Deaf School is a newly established institution dedicated to providing sign language education and vocational training for deaf youth.",
    mission:
      "To break communication barriers and provide deaf youth with the skills they need to thrive in society.",
    established_date: "2024-06-01",
    cover_image: "",
    profile_image: "",
    contact_phone: "09-444555666",
    documents: ["/docs/doc6.pdf"],
    total_received: 0,
  },
  {
    id: "h5",
    name: "Myitta Mon Orphanage",
    type: "ORPHANAGE",
    status: "PENDING",
    population: 38,
    description:
      "Myitta Mon provides shelter and education for orphaned children in the Bago region. We focus on holistic development through arts, sports, and academics.",
    mission:
      "To give every orphaned child a safe home and a path to a self-sufficient future through education and love.",
    established_date: "2018-11-05",
    cover_image: "",
    profile_image: "",
    contact_phone: "09-777888999",
    documents: ["/docs/doc7.pdf"],
    total_received: 0,
  },
  {
    id: "h6",
    name: "Peaceful Valley Elderly Care",
    type: "ELDERLY_CARE",
    status: "VERIFIED",
    population: 22,
    description:
      "Peaceful Valley offers a serene environment for elderly residents to live with dignity. We provide nutritious meals, recreational activities, and round-the-clock care.",
    mission:
      "To create a peaceful, dignified living environment where every elderly person is valued and cared for.",
    established_date: "2015-04-22",
    cover_image:
      "https://images.unsplash.com/photo-1469571486292-0ba58a3f068b?w=1200&h=400&fit=crop",
    profile_image:
      "https://images.unsplash.com/photo-1516733725897-1aa73b87c8e8?w=200&h=200&fit=crop",
    contact_phone: "09-222333444",
    documents: ["/docs/doc8.pdf"],
    total_received: 650000,
  },
];

export const mockDonations: Donation[] = [
  {
    id: "d1",
    amount: 50000,
    donor_name: "Ko Aung",
    donor_phone: "09-123456789",
    donor_email: "aung@example.com",
    status: "DISTRIBUTED",
    assigned_hostel_id: "h1",
    date: "2026-02-01",
  },
  {
    id: "d2",
    amount: 100000,
    donor_name: "Ma Thida",
    donor_phone: "09-111222333",
    status: "RECEIVED",
    date: "2026-02-03",
  },
  {
    id: "d3",
    amount: 25000,
    donor_name: "U Win",
    donor_phone: "09-444555666",
    donor_email: "uwin@example.com",
    status: "DISTRIBUTED",
    assigned_hostel_id: "h2",
    date: "2026-02-04",
  },
  {
    id: "d4",
    amount: 200000,
    donor_name: "Daw Khin",
    donor_phone: "09-777888999",
    status: "RECEIVED",
    date: "2026-02-05",
  },
  {
    id: "d5",
    amount: 75000,
    donor_name: "Ko Zaw",
    donor_phone: "09-555666777",
    status: "DISTRIBUTED",
    assigned_hostel_id: "h3",
    date: "2026-02-06",
  },
  {
    id: "d6",
    amount: 150000,
    donor_name: "Ma Su",
    donor_phone: "09-888999000",
    donor_email: "masu@example.com",
    status: "RECEIVED",
    date: "2026-02-07",
  },
];

export const mockActivities: Activity[] = [
  {
    id: "a1",
    hostel_id: "h1",
    image_url:
      "https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?w=600&h=400&fit=crop",
    caption:
      "Children received new school supplies and books this week. They are so happy and excited to learn!",
    status: "APPROVED",
    date: "2026-02-06",
  },
  {
    id: "a2",
    hostel_id: "h2",
    image_url:
      "https://images.unsplash.com/photo-1516733725897-1aa73b87c8e8?w=600&h=400&fit=crop",
    caption:
      "Our elderly residents enjoyed a traditional Thanaka ceremony and cultural celebration together.",
    status: "APPROVED",
    date: "2026-02-05",
  },
  {
    id: "a3",
    hostel_id: "h3",
    image_url:
      "https://images.unsplash.com/photo-1509099836639-18ba1795216d?w=600&h=400&fit=crop",
    caption:
      "Students at the blind school learned to read Braille with new educational materials donated by generous supporters.",
    status: "APPROVED",
    date: "2026-02-04",
  },
  {
    id: "a4",
    hostel_id: "h1",
    image_url:
      "https://images.unsplash.com/photo-1542810634-71277d95dcbb?w=600&h=400&fit=crop",
    caption:
      "Weekend art class where children expressed their dreams through painting.",
    status: "PENDING",
    date: "2026-02-07",
  },
  {
    id: "a5",
    hostel_id: "h6",
    image_url:
      "https://images.unsplash.com/photo-1469571486292-0ba58a3f068b?w=600&h=400&fit=crop",
    caption:
      "Morning exercise session for our elderly residents. Staying healthy and active together!",
    status: "APPROVED",
    date: "2026-02-03",
  },
  {
    id: "a6",
    hostel_id: "h2",
    image_url:
      "https://images.unsplash.com/photo-1532629345422-7515f3d16bb6?w=600&h=400&fit=crop",
    caption:
      "New bedding and blankets were distributed to all residents thanks to recent donations.",
    status: "PENDING",
    date: "2026-02-07",
  },
];

export const mockUsers: User[] = [
  {
    id: "u1",
    name: "Ko Aung",
    phone: "09-123456789",
    email: "aung@example.com",
    role: "DONOR",
  },
  {
    id: "u2",
    name: "Ma Hnin",
    phone: "09-222333444",
    email: "hnin@example.com",
    role: "HOSTEL_ADMIN",
    hostel_id: "h1",
  },
  {
    id: "u3",
    name: "Admin U Kyaw",
    phone: "09-999000111",
    email: "admin@fairdonation.mm",
    role: "ADMIN",
  },
];

// ============ DATA HELPERS ============
export function getHostelById(id: string): Hostel | undefined {
  return mockHostels.find((h) => h.id === id);
}

export function getHostelsByStatus(status: HostelStatus): Hostel[] {
  return mockHostels.filter((h) => h.status === status);
}

export function getHostelsByType(type?: string): Hostel[] {
  return mockHostels.filter((h) => {
    return !type || type === "ALL" || h.type === type;
  });
}

export function getVerifiedHostels(): Hostel[] {
  return mockHostels.filter((h) => h.status === "VERIFIED");
}

export function getApprovedActivities(): Activity[] {
  return mockActivities.filter((a) => a.status === "APPROVED");
}

export function getPendingActivities(): Activity[] {
  return mockActivities.filter((a) => a.status === "PENDING");
}

export function getActivitiesByHostel(hostelId: string): Activity[] {
  return mockActivities.filter((a) => a.hostel_id === hostelId);
}

export function getTotalDonations(): number {
  return mockDonations.reduce((sum, d) => sum + d.amount, 0);
}

export function getTotalDonors(): number {
  return new Set(mockDonations.map((d) => d.donor_phone)).size;
}

export function getDonationsByStatus(status: DonationStatus): Donation[] {
  return mockDonations.filter((d) => d.status === status);
}

export function getDonationsForHostel(hostelId: string): Donation[] {
  return mockDonations.filter((d) => d.assigned_hostel_id === hostelId);
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("en-US").format(amount) + " MMK";
}
