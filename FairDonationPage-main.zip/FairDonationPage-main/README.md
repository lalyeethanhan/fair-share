# Fair-Donation-Platform
School Project
