import React from 'react'

function page() {
  return (
    <div>About</div>
  )
}

export default page